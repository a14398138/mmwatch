# mmウォッチ

ステータスバーのアイコンそのものに経過時間を描画するストップウォッチ。
通知シェードを開かずに「今何分経ったか」が読める。

- 中央の 2 桁 = 分の下 2 桁
- 破線の円が 90 度ずつ実線に変わる = 100 分ごと
- 表現できる範囲は 0〜499 分（それ以上は 499 で頭打ち）

カテゴリー分け・履歴・統計・CSV 書き出しまで入っている。

---

## セットアップ

Android Studio（Ladybug 以降を推奨）と JDK 17 が必要。

### 方法 A：新規プロジェクトに上書きする（推奨）

Gradle Wrapper の jar はテキストで配布できないので、この方法がいちばん確実。

1. Android Studio で **New Project → Empty Activity (Compose)** を作る
   - Name: `MMWatch`
   - Package name: `com.example.mmwatch` ← **必ずこれに合わせる**
   - Minimum SDK: API 26
2. 作られたプロジェクトのフォルダに、この zip の中身を**上書きコピー**する
   （`gradle/wrapper/gradle-wrapper.jar` だけは元のものを残す）
3. Android Studio で **Sync Now**
4. `app/src/main/java/com/example/` の下に残っている元の `MainActivity.kt` などが
   重複していたら削除する
5. Run

### 方法 B：そのまま開く

1. zip を展開してフォルダごと Android Studio で開く
2. 「Gradle Wrapper が見つからない」と言われたら、指示に従って生成させるか
   ターミナルで `gradle wrapper` を実行する
3. Sync → Run

### バージョンについて

`gradle/libs.versions.toml` に AGP / Kotlin / Compose のバージョンを書いてあるが、
手元の Android Studio が新しいと「このバージョンには対応していない」と言われることがある。
その場合は Android Studio の **AGP Upgrade Assistant** に任せるのが早い。
Kotlin を上げたときは KSP のバージョン（`ksp = "2.0.21-1.0.25"`）も
Kotlin に合わせて上げる必要がある点だけ注意。

---

## 初回起動でやること

1. 通知の許可を求められるので許可する（Android 13 以降）
2. **設定タブ → アイコンの見え方を調整** を開く
3. 計測タブでカテゴリーを選んで開始し、実際のステータスバーを見る
4. 潰れて読めなければ設定タブのスライダーで「線の太さ」「文字の大きさ」を上げる
   - 変更はビルドし直さずに反映される（通知側は最大 1 分遅れ）

`設定` の調整用プレビューは実機のステータスバーと同じ 18dp で描いているが、
最終的な見え方は端末のレンダリングに左右されるので、必ず実機で確認すること。

---

## つまずきやすいところ

| 症状 | 見るところ |
|---|---|
| ステータスバーのアイコンが真っ白/真っ黒の四角になる | 線が太すぎる。設定タブで「線の太さ」を下げる |
| 数字が潰れて読めない | 「文字の大きさ」を上げ、「円の半径」を下げる |
| 計測を始めた瞬間に落ちる | `FOREGROUND_SERVICE_SPECIAL_USE` 権限とマニフェストの `<property>` を確認 |
| 通知が出ない | 通知権限が拒否されている。アプリ情報から許可し直す |
| しばらくすると計測が止まる | 端末のバッテリー最適化。設定→アプリ→バッテリーで「制限しない」にする（Xiaomi / OPPO / Samsung で起きやすい） |
| Room のビルドエラー | Kotlin と KSP のバージョン不一致がほぼ原因 |

---

## まだやっていないこと

意図的に外してある。必要になったら追加する。

- **プロセスが死んだときの計測復帰**
  現状は `StopwatchEngine`（メモリ上）だけで状態を持っている。
  フォアグラウンドサービス中はまず殺されないが、確実にしたければ
  開始時刻を SharedPreferences に書き出して復元する処理を足す。
- セッションへのメモ入力（DB のカラムと CSV 列だけ先に用意してある）
- カテゴリーの並べ替えと名前の編集（`sortOrder` は持っているが UI がない）
- 統計の週次/月次の比較、目標時間
- ウィジェット

---

## ファイル構成

```
app/src/main/java/com/example/mmwatch/
├── MainActivity.kt          画面の入口と通知権限の要求
├── MmWatchApp.kt            DB とチャンネルの初期化
├── data/                    Room（カテゴリー・セッション・集計クエリ）
├── timer/
│   ├── TimerIcon.kt         ★ アイコンの描画。見た目を直すならここ
│   ├── IconStyle.kt         調整値の保存
│   ├── StopwatchEngine.kt   計測状態そのもの
│   ├── NotificationHelper.kt 通知の組み立て
│   └── StopwatchService.kt  フォアグラウンドサービス
├── export/CsvExporter.kt    CSV 生成（UTF-8 BOM 付き）
└── ui/                      Compose の各画面
```

アイコンの見た目に手を入れるときは `TimerIcon.drawGlyph()` だけ直せば、
通知とアプリ内プレビューの両方が同時に変わる。
