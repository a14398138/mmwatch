package com.example.mmwatch.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

// 計器盤のイメージ。深い藍のインクに、動作中だけ灯る琥珀色を一点だけ置く。
private val Amber = Color(0xFFE8A33D)
private val AmberDeep = Color(0xFF9A6A18)
private val Ink = Color(0xFF12151C)
private val InkSoft = Color(0xFF1C2028)
private val Paper = Color(0xFFF4F5F7)
private val Slate = Color(0xFF3A4453)
private val SlateMuted = Color(0xFF8A93A0)

private val LightColors = lightColorScheme(
    primary = AmberDeep,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFDEBCB),
    onPrimaryContainer = Color(0xFF4A3105),
    secondary = Slate,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDDE3EC),
    onSecondaryContainer = Ink,
    background = Paper,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Color(0xFFE6E9EE),
    onSurfaceVariant = Slate,
    outline = SlateMuted,
    error = Color(0xFFB3261E)
)

private val DarkColors = darkColorScheme(
    primary = Amber,
    onPrimary = Color(0xFF2A1B00),
    primaryContainer = Color(0xFF553900),
    onPrimaryContainer = Color(0xFFFFDDA8),
    secondary = Color(0xFFB9C4D4),
    onSecondary = Ink,
    secondaryContainer = Color(0xFF2C3440),
    onSecondaryContainer = Color(0xFFDDE3EC),
    background = Ink,
    onBackground = Color(0xFFECEEF2),
    surface = InkSoft,
    onSurface = Color(0xFFECEEF2),
    surfaceVariant = Color(0xFF262C36),
    onSurfaceVariant = Color(0xFFB0B8C4),
    outline = Color(0xFF6B7480),
    error = Color(0xFFF2B8B5)
)

// 経過時間は等幅で。桁が動いてもレイアウトが揺れない読み取り面にする。
private val AppTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 56.sp,
        letterSpacing = (-1).sp
    ),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        letterSpacing = 0.8.sp
    )
)

@Composable
fun MMWatchTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    MaterialTheme(colorScheme = colors, typography = AppTypography, content = content)
}
