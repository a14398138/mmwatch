package com.example.mmwatch.timer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import com.example.mmwatch.MainActivity
import com.example.mmwatch.R

object NotificationHelper {

    const val CHANNEL_ID = "mmwatch_running"
    const val NOTIFICATION_ID = 1001

    fun createChannel(context: Context) {
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = context.getString(R.string.channel_desc)
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
        }
        context.getSystemService<NotificationManager>()?.createNotificationChannel(channel)
    }

    fun build(context: Context, state: StopwatchEngine.State): Notification {
        val elapsed = state.elapsedMs()
        val minutes = (elapsed / 60_000L).toInt()
        val icon = TimerIcon.buildIcon(minutes, IconStyleStore.style.value)

        val openApp = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(icon)
            .setContentTitle(state.categoryName.ifBlank { "計測中" })
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp)

        if (state.isRunning) {
            // 秒の表示はシステムのクロノメーターに任せる。通知を毎秒作り直さなくて済む。
            builder.setUsesChronometer(true)
            builder.setWhen(System.currentTimeMillis() - elapsed)
            builder.setShowWhen(true)
            builder.addAction(
                R.drawable.ic_pause, "一時停止",
                servicePendingIntent(context, StopwatchService.ACTION_PAUSE, 11)
            )
        } else {
            builder.setUsesChronometer(false)
            builder.setContentText("一時停止中 ・ ${formatHms(elapsed)}")
            builder.addAction(
                R.drawable.ic_play, "再開",
                servicePendingIntent(context, StopwatchService.ACTION_RESUME, 12)
            )
        }

        builder.addAction(
            R.drawable.ic_stop, "保存して終了",
            servicePendingIntent(context, StopwatchService.ACTION_FINISH, 13)
        )

        return builder.build()
    }

    private fun servicePendingIntent(context: Context, action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, StopwatchService::class.java).setAction(action)
        return PendingIntent.getService(
            context, requestCode, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}

fun formatHms(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}
