package com.example.mmwatch.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mmwatch.MmWatchApp
import com.example.mmwatch.data.Category
import com.example.mmwatch.data.CategoryTotal
import com.example.mmwatch.data.DailyTotal
import com.example.mmwatch.data.SessionDetail
import com.example.mmwatch.export.CsvExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

enum class Period(val label: String) {
    TODAY("今日"), WEEK("今週"), MONTH("今月"), ALL("全期間");

    fun from(): Long {
        if (this == ALL) return 0L
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        when (this) {
            WEEK -> c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
            MONTH -> c.set(Calendar.DAY_OF_MONTH, 1)
            else -> Unit
        }
        return c.timeInMillis
    }

    fun to(): Long = Long.MAX_VALUE
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = (app as MmWatchApp).repository

    private val started = SharingStarted.WhileSubscribed(5_000)

    val categories: StateFlow<List<Category>> =
        repository.categories.stateIn(viewModelScope, started, emptyList())

    val recentSessions: StateFlow<List<SessionDetail>> =
        repository.recentSessions().stateIn(viewModelScope, started, emptyList())

    private val _period = MutableStateFlow(Period.WEEK)
    val period: StateFlow<Period> = _period.asStateFlow()

    val categoryTotals: StateFlow<List<CategoryTotal>> = _period
        .flatMapLatest { repository.categoryTotals(it.from(), it.to()) }
        .stateIn(viewModelScope, started, emptyList())

    val dailyTotals: StateFlow<List<DailyTotal>> = _period
        .flatMapLatest { repository.dailyTotals(it.from(), it.to()) }
        .stateIn(viewModelScope, started, emptyList())

    fun setPeriod(p: Period) { _period.value = p }

    fun addCategory(name: String, colorArgb: Int) = viewModelScope.launch {
        repository.addCategory(name.trim(), colorArgb)
    }

    fun updateCategory(category: Category) = viewModelScope.launch {
        repository.updateCategory(category)
    }

    fun deleteCategory(category: Category) = viewModelScope.launch {
        repository.deleteCategory(category)
    }

    fun deleteSession(id: Long) = viewModelScope.launch {
        repository.deleteSession(id)
    }

    /** 現在の期間ぶんを CSV にして書き出す。件数を返す。 */
    fun exportCsv(uri: Uri, onResult: (Result<Int>) -> Unit) = viewModelScope.launch {
        val result = runCatching {
            val p = _period.value
            val rows = withContext(Dispatchers.IO) { repository.exportRange(p.from(), p.to()) }
            val csv = CsvExporter.buildCsv(rows)
            withContext(Dispatchers.IO) { CsvExporter.write(getApplication<Application>(), uri, csv) }
            rows.size
        }
        onResult(result)
    }
}
