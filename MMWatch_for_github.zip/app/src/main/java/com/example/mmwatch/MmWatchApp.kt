package com.example.mmwatch

import android.app.Application
import com.example.mmwatch.data.AppDatabase
import com.example.mmwatch.data.Repository
import com.example.mmwatch.timer.IconStyleStore
import com.example.mmwatch.timer.NotificationHelper
import com.example.mmwatch.timer.StopwatchEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MmWatchApp : Application() {

    val repository: Repository by lazy { Repository(AppDatabase.get(this).dao()) }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannel(this)
        IconStyleStore.load(this)
        // 保存済みの計測があればここで引き継ぐ。Service より先に必ず走る。
        StopwatchEngine.restore(this)
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            repository.seedIfEmpty()
        }
    }
}
