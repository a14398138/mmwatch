package com.example.mmwatch.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.example.mmwatch.timer.IconStyleStore
import com.example.mmwatch.timer.StopwatchEngine
import com.example.mmwatch.timer.StopwatchService

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TimerScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val state by StopwatchEngine.state.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val elapsed = rememberElapsedMs(state)
    val minutes = (elapsed / 60_000L).toInt()

    var pendingCategoryId by remember { mutableLongStateOf(-1L) }
    val activeCategoryId = if (state.isActive) state.categoryId else pendingCategoryId

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        StatusBarPreview(minutes = minutes, running = state.isRunning)

        Spacer(Modifier.height(28.dp))

        val readoutColor by animateColorAsState(
            if (state.isRunning) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onBackground,
            label = "readout"
        )
        Text(
            text = formatClock(elapsed),
            style = MaterialTheme.typography.displayLarge,
            color = readoutColor
        )
        Text(
            text = when {
                state.isRunning -> state.categoryName
                state.isActive -> "${state.categoryName}・一時停止中"
                else -> "待機中"
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(28.dp))

        Text(
            "カテゴリー",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        if (categories.isEmpty()) {
            Text(
                "設定タブでカテゴリーを追加すると計測を始められます。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    FilterChip(
                        selected = category.id == activeCategoryId,
                        enabled = !state.isActive,
                        onClick = { pendingCategoryId = category.id },
                        label = { Text(category.name) },
                        leadingIcon = {
                            Box(
                                Modifier
                                    .size(10.dp)
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(Color(category.colorArgb))
                            )
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(32.dp))

        if (!state.isActive) {
            val selected = categories.firstOrNull { it.id == pendingCategoryId }
            Button(
                onClick = {
                    selected?.let { StopwatchService.start(context, it.id, it.name) }
                },
                enabled = selected != null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("計測を開始")
            }
            if (selected == null && categories.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "カテゴリーを選ぶと開始できます。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        StopwatchService.send(
                            context,
                            if (state.isRunning) StopwatchService.ACTION_PAUSE
                            else StopwatchService.ACTION_RESUME
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                ) {
                    Icon(
                        if (state.isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = null
                    )
                    Spacer(Modifier.size(8.dp))
                    Text(if (state.isRunning) "一時停止" else "再開")
                }
                Button(
                    onClick = { StopwatchService.send(context, StopwatchService.ACTION_FINISH) },
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                ) {
                    Icon(Icons.Rounded.Stop, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text("保存して終了")
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = { StopwatchService.send(context, StopwatchService.ACTION_DISCARD) },
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Delete, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("保存せず破棄")
            }
        }

        Spacer(Modifier.height(24.dp))
        Text(
            "円が4分の1ずつ実線になるたびに100分。499分で頭打ちになります。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/**
 * この画面の主役。実際のステータスバーとほぼ同じ寸法でグリフを並べ、
 * 通知シェードを開かずに読めるかどうかをここで判断できるようにする。
 */
@Composable
private fun StatusBarPreview(minutes: Int, running: Boolean) {
    val style by IconStyleStore.style.collectAsState()
    Column(Modifier.fillMaxWidth()) {
        Text(
            "STATUS BAR",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0B0D12))
                .padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TimerGlyph(
                minutes = minutes,
                style = style,
                color = if (running) Color.White else Color(0xFF7C848F),
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.weight(1f))
            Text(
                "9:41",
                color = Color.White,
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.labelSmall
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "実機の見え方に近づける調整は設定タブから。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
