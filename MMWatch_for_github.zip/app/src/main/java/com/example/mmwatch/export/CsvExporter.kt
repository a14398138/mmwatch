package com.example.mmwatch.export

import android.content.Context
import android.net.Uri
import com.example.mmwatch.data.SessionDetail
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExporter {

    private val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.JAPAN)

    fun suggestFileName(): String {
        val f = SimpleDateFormat("yyyyMMdd_HHmm", Locale.JAPAN)
        return "mmwatch_${f.format(Date())}.csv"
    }

    fun buildCsv(rows: List<SessionDetail>): String {
        val sb = StringBuilder()
        sb.append("id,category,started_at,ended_at,duration_ms,duration_hms,minutes,note\n")
        rows.forEach { r ->
            sb.append(r.id).append(',')
                .append(escape(r.categoryName ?: "未分類")).append(',')
                .append(escape(stamp.format(Date(r.startedAt)))).append(',')
                .append(escape(stamp.format(Date(r.endedAt)))).append(',')
                .append(r.durationMs).append(',')
                .append(escape(hms(r.durationMs))).append(',')
                .append(r.durationMs / 60_000).append(',')
                .append(escape(r.note))
                .append('\n')
        }
        return sb.toString()
    }

    /** Excel が UTF-8 と判定できるよう BOM を付ける。 */
    fun write(context: Context, uri: Uri, csv: String) {
        context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
            out.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
            out.write(csv.toByteArray(Charsets.UTF_8))
            out.flush()
        } ?: error("書き込み先を開けませんでした")
    }

    private fun hms(ms: Long): String {
        val total = ms / 1000
        return String.format(Locale.US, "%d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
    }

    private fun escape(value: String): String {
        val needsQuote = value.any { it == ',' || it == '"' || it == '\n' || it == '\r' }
        val body = value.replace("\"", "\"\"")
        return if (needsQuote) "\"$body\"" else body
    }
}
