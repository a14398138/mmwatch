package com.example.mmwatch.data

import kotlinx.coroutines.flow.Flow

class Repository(private val dao: AppDao) {

    val categories: Flow<List<Category>> = dao.observeCategories()

    fun recentSessions(limit: Int = 300): Flow<List<SessionDetail>> = dao.observeRecent(limit)

    fun categoryTotals(from: Long, to: Long): Flow<List<CategoryTotal>> =
        dao.observeCategoryTotals(from, to)

    fun dailyTotals(from: Long, to: Long): Flow<List<DailyTotal>> =
        dao.observeDailyTotals(from, to)

    suspend fun exportRange(from: Long, to: Long): List<SessionDetail> = dao.rangeForExport(from, to)

    suspend fun addCategory(name: String, colorArgb: Int) {
        dao.insertCategory(Category(name = name, colorArgb = colorArgb))
    }

    suspend fun updateCategory(category: Category) = dao.updateCategory(category)

    suspend fun deleteCategory(category: Category) = dao.deleteCategory(category)

    suspend fun deleteSession(id: Long) = dao.deleteSession(id)

    suspend fun saveSession(categoryId: Long, startedAt: Long, endedAt: Long, durationMs: Long, note: String = "") {
        dao.insertSession(
            Session(
                categoryId = categoryId,
                startedAt = startedAt,
                endedAt = endedAt,
                durationMs = durationMs,
                note = note
            )
        )
    }

    /** 初回起動時だけ、空のリストを避けるために既定カテゴリーを入れる。 */
    suspend fun seedIfEmpty() {
        if (dao.countCategories() > 0) return
        val defaults = listOf(
            "勉強" to 0xFFE8A33D.toInt(),
            "読書" to 0xFF6FA8A0.toInt(),
            "運動" to 0xFFD46A6A.toInt(),
            "作業" to 0xFF7C89B8.toInt()
        )
        defaults.forEachIndexed { index, (name, color) ->
            dao.insertCategory(Category(name = name, colorArgb = color, sortOrder = index))
        }
    }
}
