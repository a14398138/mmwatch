package com.example.mmwatch.timer

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * ステータスバーのアイコンは実機だと 24dp 程度まで縮むので、
 * 線の太さや文字サイズは端末を見ながら詰める必要がある。
 * 数値をここに集約して、設定画面のスライダーから調整できるようにしてある。
 * 比率はすべてキャンバス一辺に対する割合。
 *
 * 既定値は実機で詰めた値。細い点線の大きな円 + 大きめの 2 桁、という構成。
 */
data class IconStyle(
    val radiusRatio: Float = 0.480f,
    val strokeRatio: Float = 0.030f,
    val dashOnRatio: Float = 0.030f,
    val dashOffRatio: Float = 0.020f,
    val textRatio: Float = 0.614f,
    val baselineRatio: Float = 0.181f
) {
    companion object {
        const val CANVAS_PX = 96
        val Default = IconStyle()

        // スライダーの可動域。既定値が端に張り付かないよう上下に余白を持たせてある。
        val RADIUS_RANGE = 0.25f..0.50f
        val STROKE_RANGE = 0.015f..0.160f
        val DASH_ON_RANGE = 0.015f..0.250f
        val DASH_OFF_RANGE = 0.010f..0.200f
        val TEXT_RANGE = 0.250f..0.750f
        val BASELINE_RANGE = 0.050f..0.320f
    }
}

object IconStyleStore {

    private const val PREF = "mmwatch_icon_style"

    /**
     * 既定値を変えたとき、旧バージョンで保存済みの値が残っていると新しい既定値が出てこない。
     * この番号を上げると、保存済みの値を新しい既定値に載せ替える。
     */
    private const val DEFAULTS_VERSION = 2
    private const val KEY_VERSION = "defaultsVersion"

    private val _style = MutableStateFlow(IconStyle.Default)
    val style: StateFlow<IconStyle> = _style.asStateFlow()

    fun load(context: Context) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val d = IconStyle.Default

        if (p.getInt(KEY_VERSION, 0) < DEFAULTS_VERSION) {
            save(context, d)
            return
        }

        _style.value = IconStyle(
            radiusRatio = p.getFloat("radius", d.radiusRatio),
            strokeRatio = p.getFloat("stroke", d.strokeRatio),
            dashOnRatio = p.getFloat("dashOn", d.dashOnRatio),
            dashOffRatio = p.getFloat("dashOff", d.dashOffRatio),
            textRatio = p.getFloat("text", d.textRatio),
            baselineRatio = p.getFloat("baseline", d.baselineRatio)
        )
    }

    fun save(context: Context, style: IconStyle) {
        _style.value = style
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().apply {
            putFloat("radius", style.radiusRatio)
            putFloat("stroke", style.strokeRatio)
            putFloat("dashOn", style.dashOnRatio)
            putFloat("dashOff", style.dashOffRatio)
            putFloat("text", style.textRatio)
            putFloat("baseline", style.baselineRatio)
            putInt(KEY_VERSION, DEFAULTS_VERSION)
        }.apply()
    }

    fun reset(context: Context) = save(context, IconStyle.Default)
}
