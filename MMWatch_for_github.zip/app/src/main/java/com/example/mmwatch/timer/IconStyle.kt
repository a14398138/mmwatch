package com.example.mmwatch.timer

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * ステータスバーのアイコンは実機だと 24dp 程度まで縮むので、
 * 線の太さや文字サイズは端末を見ながら詰める必要がある。
 * 数値をここに集約して、設定画面のスライダーから調整できるようにしてある。
 * 比率はすべてキャンバス一辺に対する割合。
 */
data class IconStyle(
    val radiusRatio: Float = 0.40f,
    val strokeRatio: Float = 0.085f,
    val dashOnRatio: Float = 0.10f,
    val dashOffRatio: Float = 0.075f,
    val textRatio: Float = 0.44f,
    val baselineRatio: Float = 0.16f
) {
    companion object {
        const val CANVAS_PX = 96
        val Default = IconStyle()
    }
}

object IconStyleStore {

    private const val PREF = "mmwatch_icon_style"

    private val _style = MutableStateFlow(IconStyle.Default)
    val style: StateFlow<IconStyle> = _style.asStateFlow()

    fun load(context: Context) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val d = IconStyle.Default
        _style.value = IconStyle(
            radiusRatio = p.getFloat("radius", d.radiusRatio),
            strokeRatio = p.getFloat("stroke", d.strokeRatio),
            dashOnRatio = p.getFloat("dashOn", d.dashOnRatio),
            dashOffRatio = p.getFloat("dashOff", d.dashOffRatio),
            textRatio = p.getFloat("text", d.textRatio),
            baselineRatio = p.getFloat("baseline", d.baselineRatio)
        )
    }

    fun save(context: Context, style: IconStyle) {
        _style.value = style
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().apply {
            putFloat("radius", style.radiusRatio)
            putFloat("stroke", style.strokeRatio)
            putFloat("dashOn", style.dashOnRatio)
            putFloat("dashOff", style.dashOffRatio)
            putFloat("text", style.textRatio)
            putFloat("baseline", style.baselineRatio)
        }.apply()
    }

    fun reset(context: Context) = save(context, IconStyle.Default)
}
