package com.example.mmwatch.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val colorArgb: Int,
    val sortOrder: Int = 0
)

@Entity(
    tableName = "sessions",
    indices = [Index("categoryId"), Index("startedAt")]
)
data class Session(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val categoryId: Long,
    val startedAt: Long,
    val endedAt: Long,
    val durationMs: Long,
    val note: String = ""
)

/** 履歴・CSV用。カテゴリーを消しても記録は残るので name は null になりうる。 */
data class SessionDetail(
    val id: Long,
    val categoryId: Long,
    val startedAt: Long,
    val endedAt: Long,
    val durationMs: Long,
    val note: String,
    val categoryName: String?,
    val categoryColor: Int?
)

data class CategoryTotal(
    val categoryId: Long,
    val name: String,
    val colorArgb: Int,
    val totalMs: Long,
    val sessionCount: Int
)

data class DailyTotal(
    val day: String,
    val totalMs: Long
)
