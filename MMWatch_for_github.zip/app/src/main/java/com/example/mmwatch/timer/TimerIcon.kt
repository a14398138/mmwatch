package com.example.mmwatch.timer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.core.graphics.drawable.IconCompat
import kotlin.math.PI
import kotlin.math.roundToInt

/**
 * 「下2桁の数字 + 破線の円を90度ずつ実線化して百の位を表す」グリフ。
 * 0〜499分まで表現でき、それ以上は 499 で頭打ちにする。
 *
 * ステータスバーの小アイコンはアルファチャンネル（形）だけが使われ、
 * 色はシステム側で塗り直される。だから白で描いておけばよい。
 */
object TimerIcon {

    const val MAX_MINUTES = 499

    private var cacheKey: Pair<Int, IconStyle>? = null
    private var cached: IconCompat? = null

    fun buildIcon(totalMinutes: Int, iconStyle: IconStyle): IconCompat {
        val clamped = totalMinutes.coerceIn(0, MAX_MINUTES)
        val key = clamped to iconStyle
        cacheKey?.let { if (it == key) cached?.let { icon -> return icon } }

        val size = IconStyle.CANVAS_PX
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        drawGlyph(Canvas(bitmap), size.toFloat(), clamped, iconStyle, Color.WHITE)

        val icon = IconCompat.createWithBitmap(bitmap)
        cacheKey = key
        cached = icon
        return icon
    }

    /**
     * アプリ内プレビューでも同じ描画を使うため、Canvas を受け取る形にしてある。
     * ここを直せば通知アイコンとプレビューが同時に変わる。
     */
    fun drawGlyph(canvas: Canvas, size: Float, totalMinutes: Int, iconStyle: IconStyle, color: Int) {
        val minutes = totalMinutes.coerceIn(0, MAX_MINUTES)
        val mm = minutes % 100
        val quarters = (minutes / 100).coerceIn(0, 4)

        val center = size / 2f
        val stroke = size * iconStyle.strokeRatio

        // 線は半径の中心線上に太さぶん広がる。キャンバスからはみ出すと端が切れるので抑える。
        val maxRadius = center - stroke / 2f
        val radius = (size * iconStyle.radiusRatio).coerceAtMost(maxRadius)

        val textPx = size * iconStyle.textRatio

        val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.style = Paint.Style.STROKE
            strokeWidth = stroke
            strokeCap = Paint.Cap.BUTT
        }

        // 土台の破線円。
        // 破線の周期が円周を割り切らないと、一周したところで継ぎ目が出て点の間隔が乱れる。
        // 周期をわずかに伸縮させて整数個ぴったりに収める。
        val circumference = 2f * PI.toFloat() * radius
        val rawPeriod = size * (iconStyle.dashOnRatio + iconStyle.dashOffRatio)
        val dashed = if (rawPeriod > 0.1f && circumference > rawPeriod) {
            val count = (circumference / rawPeriod).roundToInt().coerceAtLeast(1)
            val scale = circumference / (rawPeriod * count)
            Paint(ringPaint).apply {
                pathEffect = DashPathEffect(
                    floatArrayOf(
                        size * iconStyle.dashOnRatio * scale,
                        size * iconStyle.dashOffRatio * scale
                    ),
                    0f
                )
            }
        } else {
            Paint(ringPaint)
        }
        canvas.drawCircle(center, center, radius, dashed)

        // 百の位ぶんだけ実線で上書き（12時方向から時計回りに90度ずつ）
        if (quarters > 0) {
            val rect = RectF(center - radius, center - radius, center + radius, center + radius)
            for (i in 0 until quarters) {
                canvas.drawArc(rect, -90f + i * 90f, 90f, false, ringPaint)
            }
        }

        // 中央の 2 桁
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = textPx
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val label = mm.toString().padStart(2, '0')
        canvas.drawText(label, center, center + size * iconStyle.baselineRatio, textPaint)
    }
}
