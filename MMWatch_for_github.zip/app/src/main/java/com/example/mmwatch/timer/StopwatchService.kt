package com.example.mmwatch.timer

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.mmwatch.MmWatchApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * 計測中プロセスを生かしておくためのフォアグラウンドサービス。
 * 通知の作り直しは「表示中の分が変わったとき」と「再生/一時停止が切り替わったとき」だけ。
 */
class StopwatchService : Service() {

    companion object {
        const val ACTION_START = "com.example.mmwatch.action.START"
        const val ACTION_PAUSE = "com.example.mmwatch.action.PAUSE"
        const val ACTION_RESUME = "com.example.mmwatch.action.RESUME"
        const val ACTION_FINISH = "com.example.mmwatch.action.FINISH"
        const val ACTION_DISCARD = "com.example.mmwatch.action.DISCARD"
        const val ACTION_REFRESH = "com.example.mmwatch.action.REFRESH"

        const val EXTRA_CATEGORY_ID = "categoryId"
        const val EXTRA_CATEGORY_NAME = "categoryName"

        fun start(context: Context, categoryId: Long, categoryName: String) {
            val intent = Intent(context, StopwatchService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_CATEGORY_ID, categoryId)
                .putExtra(EXTRA_CATEGORY_NAME, categoryName)
            ContextCompat.startForegroundService(context, intent)
        }

        fun send(context: Context, action: String) {
            val intent = Intent(context, StopwatchService::class.java).setAction(action)
            ContextCompat.startForegroundService(context, intent)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var lastMinuteShown = -1
    private var lastRunningShown: Boolean? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        scope.launch {
            while (isActive) {
                delay(1000)
                pushIfChanged()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 起動経路にかかわらず 5 秒以内に startForeground する必要がある
        promoteToForeground()

        when (intent?.action) {
            ACTION_START -> {
                val id = intent.getLongExtra(EXTRA_CATEGORY_ID, -1L)
                val name = intent.getStringExtra(EXTRA_CATEGORY_NAME).orEmpty()
                StopwatchEngine.start(id, name)
            }
            ACTION_PAUSE -> StopwatchEngine.pause()
            ACTION_RESUME -> StopwatchEngine.resume()
            ACTION_FINISH -> {
                finishAndSave()
                return START_NOT_STICKY
            }
            ACTION_DISCARD -> {
                StopwatchEngine.discard()
                shutdown()
                return START_NOT_STICKY
            }
        }

        if (!StopwatchEngine.state.value.isActive) {
            shutdown()
            return START_NOT_STICKY
        }
        pushNotification(force = true)
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun promoteToForeground() {
        val notification = NotificationHelper.build(this, StopwatchEngine.state.value)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NotificationHelper.NOTIFICATION_ID, notification, type)
    }

    private fun pushIfChanged() {
        val state = StopwatchEngine.state.value
        if (!state.isActive) return
        val minute = (state.elapsedMs() / 60_000L).toInt()
        if (minute != lastMinuteShown || state.isRunning != lastRunningShown) {
            pushNotification(force = true)
        }
    }

    private fun pushNotification(force: Boolean) {
        val state = StopwatchEngine.state.value
        if (!state.isActive) return
        val minute = (state.elapsedMs() / 60_000L).toInt()
        if (!force && minute == lastMinuteShown && state.isRunning == lastRunningShown) return

        lastMinuteShown = minute
        lastRunningShown = state.isRunning

        val notification = NotificationHelper.build(this, state)
        try {
            NotificationManagerCompat.from(this)
                .notify(NotificationHelper.NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            // 通知権限が拒否されている場合。サービス自体は動き続ける。
        }
    }

    private fun finishAndSave() {
        val snapshot = StopwatchEngine.finish()
        if (snapshot == null || snapshot.categoryId < 0 || snapshot.baseMs <= 0L) {
            shutdown()
            return
        }
        val repository = (application as MmWatchApp).repository
        CoroutineScope(Dispatchers.IO).launch {
            repository.saveSession(
                categoryId = snapshot.categoryId,
                startedAt = snapshot.startedAtWall,
                // 一時停止を挟むと「開始 + 計測時間」と実際の終了時刻はずれる。終了は実時刻で記録する。
                endedAt = System.currentTimeMillis(),
                durationMs = snapshot.baseMs
            )
        }
        shutdown()
    }

    private fun shutdown() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
}
