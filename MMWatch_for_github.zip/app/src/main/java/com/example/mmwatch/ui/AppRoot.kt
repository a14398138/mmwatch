package com.example.mmwatch.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel

private data class Tab(val label: String, val icon: ImageVector)

@Composable
fun AppRoot(viewModel: MainViewModel = viewModel()) {
    val tabs = remember {
        listOf(
            Tab("計測", Icons.Rounded.Timer),
            Tab("履歴", Icons.Rounded.History),
            Tab("統計", Icons.Rounded.BarChart),
            Tab("設定", Icons.Rounded.Tune)
        )
    }
    var selected by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selected == index,
                        onClick = { selected = index },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { inner ->
        val content = Modifier.padding(inner)
        when (selected) {
            0 -> TimerScreen(viewModel, content)
            1 -> HistoryScreen(viewModel, content)
            2 -> StatsScreen(viewModel, content)
            else -> SettingsScreen(viewModel, content)
        }
    }
}
