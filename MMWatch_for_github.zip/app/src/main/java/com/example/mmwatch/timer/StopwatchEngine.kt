package com.example.mmwatch.timer

import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 計測の状態そのもの。Service と UI の両方がここを見る。
 * 経過時間は elapsedRealtime 基準なので、端末の時刻をいじられてもずれない。
 */
object StopwatchEngine {

    data class State(
        val isRunning: Boolean = false,
        val categoryId: Long = -1L,
        val categoryName: String = "",
        val startedAtWall: Long = 0L,
        val baseMs: Long = 0L,
        val runStartRealtime: Long = 0L
    ) {
        val isActive: Boolean get() = startedAtWall > 0L

        fun elapsedMs(nowRealtime: Long = SystemClock.elapsedRealtime()): Long =
            if (isRunning) baseMs + (nowRealtime - runStartRealtime) else baseMs
    }

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    fun start(categoryId: Long, categoryName: String) {
        _state.value = State(
            isRunning = true,
            categoryId = categoryId,
            categoryName = categoryName,
            startedAtWall = System.currentTimeMillis(),
            baseMs = 0L,
            runStartRealtime = SystemClock.elapsedRealtime()
        )
    }

    fun pause() {
        val s = _state.value
        if (!s.isRunning) return
        _state.value = s.copy(isRunning = false, baseMs = s.elapsedMs())
    }

    fun resume() {
        val s = _state.value
        if (s.isRunning || !s.isActive) return
        _state.value = s.copy(isRunning = true, runStartRealtime = SystemClock.elapsedRealtime())
    }

    /** 保存対象のスナップショットを返してから状態を空にする。 */
    fun finish(): State? {
        val s = _state.value
        if (!s.isActive) return null
        val settled = s.copy(isRunning = false, baseMs = s.elapsedMs())
        _state.value = State()
        return settled
    }

    fun discard() {
        _state.value = State()
    }
}
