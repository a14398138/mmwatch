package com.example.mmwatch.timer

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 計測の状態そのもの。Service と UI の両方がここを見る。
 *
 * 進行中の経過時間は elapsedRealtime 基準なので、端末の時刻をいじられてもずれない。
 * ただしメモリ上だけだと、Android にプロセスを落とされた時点で計測が消える。
 * 状態変化のたびに SharedPreferences へ書き、起動時に復元することで
 * 再起動・プロセス強制終了をまたいでも計測が続くようにしてある。
 */
object StopwatchEngine {

    private const val PREF = "mmwatch_session"

    data class State(
        val isRunning: Boolean = false,
        val categoryId: Long = -1L,
        val categoryName: String = "",
        val startedAtWall: Long = 0L,
        val baseMs: Long = 0L,
        val runStartRealtime: Long = 0L
    ) {
        val isActive: Boolean get() = startedAtWall > 0L

        fun elapsedMs(nowRealtime: Long = SystemClock.elapsedRealtime()): Long =
            if (isRunning) baseMs + (nowRealtime - runStartRealtime) else baseMs
    }

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private var prefs: SharedPreferences? = null

    /** Application.onCreate から一度だけ呼ぶ。保存済みの計測があれば引き継ぐ。 */
    fun restore(context: Context) {
        val p = context.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        prefs = p

        val startedAtWall = p.getLong("startedAtWall", 0L)
        if (startedAtWall <= 0L) return

        val running = p.getBoolean("running", false)
        val savedBase = p.getLong("baseMs", 0L)
        val runStartWall = p.getLong("runStartWall", 0L)

        // 再起動を挟むと elapsedRealtime は 0 に戻る。
        // 動作中だった分は実時刻の差分で埋め、そこから改めて elapsedRealtime で刻む。
        val base = if (running && runStartWall > 0L) {
            savedBase + (System.currentTimeMillis() - runStartWall).coerceAtLeast(0L)
        } else {
            savedBase
        }

        _state.value = State(
            isRunning = running,
            categoryId = p.getLong("categoryId", -1L),
            categoryName = p.getString("categoryName", "").orEmpty(),
            startedAtWall = startedAtWall,
            baseMs = base,
            runStartRealtime = SystemClock.elapsedRealtime()
        )
    }

    fun start(categoryId: Long, categoryName: String) {
        update(
            State(
                isRunning = true,
                categoryId = categoryId,
                categoryName = categoryName,
                startedAtWall = System.currentTimeMillis(),
                baseMs = 0L,
                runStartRealtime = SystemClock.elapsedRealtime()
            )
        )
    }

    fun pause() {
        val s = _state.value
        if (!s.isRunning) return
        update(s.copy(isRunning = false, baseMs = s.elapsedMs()))
    }

    fun resume() {
        val s = _state.value
        if (s.isRunning || !s.isActive) return
        update(s.copy(isRunning = true, runStartRealtime = SystemClock.elapsedRealtime()))
    }

    /** 保存対象のスナップショットを返してから状態を空にする。 */
    fun finish(): State? {
        val s = _state.value
        if (!s.isActive) return null
        val settled = s.copy(isRunning = false, baseMs = s.elapsedMs())
        update(State())
        return settled
    }

    fun discard() {
        update(State())
    }

    private fun update(next: State) {
        _state.value = next
        val p = prefs ?: return
        p.edit().apply {
            if (!next.isActive) {
                clear()
            } else {
                putBoolean("running", next.isRunning)
                putLong("categoryId", next.categoryId)
                putString("categoryName", next.categoryName)
                putLong("startedAtWall", next.startedAtWall)
                putLong("baseMs", next.baseMs)
                // 動作中なら「この区間が始まった実時刻」を残す。再起動後の復元に使う。
                putLong("runStartWall", if (next.isRunning) System.currentTimeMillis() else 0L)
            }
        }.apply()
    }
}
