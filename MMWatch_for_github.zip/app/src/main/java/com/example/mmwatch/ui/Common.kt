package com.example.mmwatch.ui

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import com.example.mmwatch.timer.IconStyle
import com.example.mmwatch.timer.StopwatchEngine
import com.example.mmwatch.timer.TimerIcon
import kotlinx.coroutines.delay
import java.util.Locale

/** 通知アイコンと同じ描画コードでプレビューする。ここが実機の見え方の代役になる。 */
@Composable
fun TimerGlyph(
    minutes: Int,
    style: IconStyle,
    color: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        drawIntoCanvas { canvas ->
            TimerIcon.drawGlyph(
                canvas.nativeCanvas,
                size.minDimension,
                minutes,
                style,
                color.toArgb()
            )
        }
    }
}

@Composable
fun rememberElapsedMs(state: StopwatchEngine.State): Long {
    var tick by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(state) {
        // 停止中は elapsedMs が tick を見ないので、回すだけ無駄になる。
        if (!state.isRunning) return@LaunchedEffect
        while (true) {
            tick = SystemClock.elapsedRealtime()
            delay(100)
        }
    }
    return state.elapsedMs(tick)
}

fun formatClock(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return String.format(Locale.US, "%d:%02d:%02d", h, m, s)
}

fun formatDurationJa(ms: Long): String {
    val minutes = ms / 60_000
    val h = minutes / 60
    val m = minutes % 60
    return when {
        h > 0 -> "${h}時間${m}分"
        minutes > 0 -> "${m}分"
        else -> "1分未満"
    }
}
