package com.example.mmwatch.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun StatsScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    val period by viewModel.period.collectAsState()
    val totals by viewModel.categoryTotals.collectAsState()
    val daily by viewModel.dailyTotals.collectAsState()
    val grandTotal = totals.sumOf { it.totalMs }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Period.entries.forEach { p ->
                FilterChip(
                    selected = p == period,
                    onClick = { viewModel.setPeriod(p) },
                    label = { Text(p.label) }
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        Text(
            "TOTAL",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            formatClock(grandTotal),
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.headlineLarge
        )
        Text(
            "${totals.sumOf { it.sessionCount }} 件の記録",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(28.dp))

        Text("カテゴリー別", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(12.dp))

        if (totals.isEmpty()) {
            Text(
                "この期間の記録はまだありません。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            val max = totals.maxOf { it.totalMs }.coerceAtLeast(1L)
            totals.forEach { row ->
                Column(Modifier.padding(bottom = 14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(row.name, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.weight(1f))
                        Text(
                            formatDurationJa(row.totalMs),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth((row.totalMs.toFloat() / max.toFloat()).coerceIn(0.02f, 1f))
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(Color(row.colorArgb))
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("日別の推移", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(12.dp))

        if (daily.isEmpty()) {
            Text(
                "グラフを描くだけの記録がまだありません。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            DailyBars(
                values = daily.map { it.totalMs },
                barColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            )
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                Text(
                    shortDay(daily.first().day),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.weight(1f))
                Text(
                    shortDay(daily.last().day),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun DailyBars(values: List<Long>, barColor: Color, modifier: Modifier = Modifier) {
    val max = (values.maxOrNull() ?: 1L).coerceAtLeast(1L).toFloat()
    Canvas(modifier) {
        val gap = if (values.size > 1) 4f else 0f
        val barWidth = ((size.width - gap * (values.size - 1)) / values.size).coerceAtLeast(1f)
        values.forEachIndexed { index, value ->
            val h = (value.toFloat() / max) * size.height
            drawRect(
                color = barColor,
                topLeft = Offset(index * (barWidth + gap), size.height - h),
                size = Size(barWidth, h)
            )
        }
    }
}

private val isoDay = SimpleDateFormat("yyyy-MM-dd", Locale.JAPAN)

private fun shortDay(iso: String): String = runCatching {
    val d = isoDay.parse(iso) ?: return iso
    SimpleDateFormat("M/d", Locale.JAPAN).format(d)
}.getOrDefault(iso)
