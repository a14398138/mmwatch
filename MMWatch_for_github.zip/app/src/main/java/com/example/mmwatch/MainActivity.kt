package com.example.mmwatch

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import com.example.mmwatch.timer.StopwatchEngine
import com.example.mmwatch.timer.StopwatchService
import com.example.mmwatch.ui.AppRoot
import com.example.mmwatch.ui.theme.MMWatchTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val permissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

        setContent {
            MMWatchTheme {
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                AppRoot()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // 復元された計測が残っているのに通知が消えている場合、ここで復帰させる。
        // フォアグラウンドからの起動なので FGS 制限には引っかからない。
        if (StopwatchEngine.state.value.isActive) {
            StopwatchService.send(this, StopwatchService.ACTION_REFRESH)
        }
    }
}
