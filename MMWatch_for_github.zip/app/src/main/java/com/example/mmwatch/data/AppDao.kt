package com.example.mmwatch.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // ---- カテゴリー ----
    @Query("SELECT * FROM categories ORDER BY sortOrder, id")
    fun observeCategories(): Flow<List<Category>>

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun countCategories(): Int

    @Insert
    suspend fun insertCategory(category: Category): Long

    @Update
    suspend fun updateCategory(category: Category)

    @Delete
    suspend fun deleteCategory(category: Category)

    // ---- セッション ----
    @Insert
    suspend fun insertSession(session: Session): Long

    @Query("DELETE FROM sessions WHERE id = :id")
    suspend fun deleteSession(id: Long)

    @Query(
        """
        SELECT s.id AS id, s.categoryId AS categoryId, s.startedAt AS startedAt,
               s.endedAt AS endedAt, s.durationMs AS durationMs, s.note AS note,
               c.name AS categoryName, c.colorArgb AS categoryColor
        FROM sessions s LEFT JOIN categories c ON c.id = s.categoryId
        ORDER BY s.startedAt DESC
        LIMIT :limit
        """
    )
    fun observeRecent(limit: Int): Flow<List<SessionDetail>>

    @Query(
        """
        SELECT s.id AS id, s.categoryId AS categoryId, s.startedAt AS startedAt,
               s.endedAt AS endedAt, s.durationMs AS durationMs, s.note AS note,
               c.name AS categoryName, c.colorArgb AS categoryColor
        FROM sessions s LEFT JOIN categories c ON c.id = s.categoryId
        WHERE s.startedAt >= :from AND s.startedAt < :to
        ORDER BY s.startedAt ASC
        """
    )
    suspend fun rangeForExport(from: Long, to: Long): List<SessionDetail>

    // ---- 集計 ----
    @Query(
        """
        SELECT c.id AS categoryId, c.name AS name, c.colorArgb AS colorArgb,
               SUM(s.durationMs) AS totalMs, COUNT(s.id) AS sessionCount
        FROM sessions s JOIN categories c ON c.id = s.categoryId
        WHERE s.startedAt >= :from AND s.startedAt < :to
        GROUP BY c.id
        ORDER BY totalMs DESC
        """
    )
    fun observeCategoryTotals(from: Long, to: Long): Flow<List<CategoryTotal>>

    @Query(
        """
        SELECT strftime('%Y-%m-%d', s.startedAt / 1000, 'unixepoch', 'localtime') AS day,
               SUM(s.durationMs) AS totalMs
        FROM sessions s
        WHERE s.startedAt >= :from AND s.startedAt < :to
        GROUP BY day
        ORDER BY day ASC
        """
    )
    fun observeDailyTotals(from: Long, to: Long): Flow<List<DailyTotal>>
}
