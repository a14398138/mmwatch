# MMWatch — GitHub Actions APK build

1. Create a GitHub repository from your phone.
2. Upload the contents of this ZIP to the repository.
3. Open **Actions** → **Build APK** → **Run workflow**.
4. Wait for the workflow to finish.
5. Open the completed workflow run and download the **MMWatch-debug-apk** artifact.
6. Extract the ZIP and install the APK on your Android phone.

The workflow builds the debug APK with JDK 17 and Gradle.
