package com.example.mmwatch.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.example.mmwatch.export.CsvExporter
import com.example.mmwatch.timer.IconStyle
import com.example.mmwatch.timer.IconStyleStore

private val palette = listOf(
    0xFFE7222E, 0xFF6FA8A0, 0xFFD46A6A,
    0xFF7C89B8, 0xFF9C7BB0, 0xFF7FA55C
).map { it.toInt() }

@Composable
fun SettingsScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val categories by viewModel.categories.collectAsState()
    val period by viewModel.period.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        viewModel.exportCsv(uri) { result ->
            val message = result.fold(
                onSuccess = { "$it 件を書き出しました" },
                onFailure = { "書き出せませんでした: ${it.message}" }
            )
            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        }
    }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // ---- カテゴリー ----
        SectionTitle("カテゴリー")
        categories.forEach { category ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(Color(category.colorArgb))
                )
                Spacer(Modifier.size(12.dp))
                Text(category.name, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { viewModel.deleteCategory(category) }) {
                    Icon(
                        Icons.Rounded.DeleteOutline,
                        contentDescription = "${category.name} を削除",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Text(
            "カテゴリーを削除しても過去の記録は残り、履歴では「未分類」として表示されます。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { showAddDialog = true }) {
            Icon(Icons.Rounded.Add, contentDescription = null)
            Spacer(Modifier.size(8.dp))
            Text("カテゴリーを追加")
        }

        Spacer(Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(Modifier.height(20.dp))

        // ---- CSV ----
        SectionTitle("CSV で書き出す")
        Text(
            "統計タブで選んでいる期間（現在: ${period.label}）を書き出します。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        Button(onClick = { exportLauncher.launch(CsvExporter.suggestFileName()) }) {
            Icon(Icons.Rounded.FileDownload, contentDescription = null)
            Spacer(Modifier.size(8.dp))
            Text("保存先を選ぶ")
        }

        Spacer(Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(Modifier.height(20.dp))

        // ---- アイコン調整 ----
        IconTuning()

        Spacer(Modifier.height(40.dp))
    }

    if (showAddDialog) {
        AddCategoryDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, color ->
                viewModel.addCategory(name, color)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall)
    Spacer(Modifier.height(10.dp))
}

/**
 * 実機のステータスバーは端末ごとに描画サイズも太さの見え方も違う。
 * ビルドし直さずに詰められるよう、ここで直接いじれるようにしてある。
 */
@Composable
private fun IconTuning() {
    val context = LocalContext.current
    val style by IconStyleStore.style.collectAsState()
    val samples = listOf(7, 42, 99, 158, 305, 499)

    SectionTitle("アイコンの見え方を調整")
    Text(
        "実際のステータスバーと同じ 18dp で並べています。読めなければ線を太く、文字を大きく。",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(12.dp))

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0B0D12))
            .padding(vertical = 10.dp, horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        samples.forEach { minutes ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                TimerGlyph(minutes, style, Color.White, Modifier.size(18.dp))
                Spacer(Modifier.height(4.dp))
                Text(
                    "$minutes",
                    color = Color(0xFF7C848F),
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }

    Spacer(Modifier.height(8.dp))
    // 拡大版。形そのものを確認するとき用。
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        listOf(42, 158, 499).forEach { minutes ->
            Box(
                Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0B0D12)),
                contentAlignment = Alignment.Center
            ) {
                TimerGlyph(minutes, style, Color.White, Modifier.size(56.dp))
            }
        }
    }

    Spacer(Modifier.height(16.dp))

    TuningSlider("円の半径", style.radiusRatio, IconStyle.RADIUS_RANGE) {
        IconStyleStore.save(context, style.copy(radiusRatio = it))
    }
    TuningSlider("線の太さ", style.strokeRatio, IconStyle.STROKE_RANGE) {
        IconStyleStore.save(context, style.copy(strokeRatio = it))
    }
    TuningSlider("破線の実線部", style.dashOnRatio, IconStyle.DASH_ON_RANGE) {
        IconStyleStore.save(context, style.copy(dashOnRatio = it))
    }
    TuningSlider("破線の隙間", style.dashOffRatio, IconStyle.DASH_OFF_RANGE) {
        IconStyleStore.save(context, style.copy(dashOffRatio = it))
    }
    TuningSlider("文字の大きさ", style.textRatio, IconStyle.TEXT_RANGE) {
        IconStyleStore.save(context, style.copy(textRatio = it))
    }
    TuningSlider("文字の縦位置", style.baselineRatio, IconStyle.BASELINE_RANGE) {
        IconStyleStore.save(context, style.copy(baselineRatio = it))
    }

    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(onClick = { IconStyleStore.reset(context) }) { Text("既定値に戻す") }
    }
    Spacer(Modifier.height(8.dp))
    Text(
        "変更はステータスバーにすぐ反映されます。",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun TuningSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column(Modifier.padding(bottom = 4.dp)) {
        Row {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.weight(1f))
            Text(
                String.format(java.util.Locale.US, "%.3f", value),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Slider(
            value = value.coerceIn(range),
            onValueChange = onChange,
            valueRange = range
        )
    }
}

@Composable
private fun AddCategoryDialog(onDismiss: () -> Unit, onConfirm: (String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var colorIndex by remember { mutableIntStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("カテゴリーを追加") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("名前") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Text("色", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    palette.forEachIndexed { index, argb ->
                        Box(
                            Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(argb))
                                .border(
                                    width = if (index == colorIndex) 3.dp else 0.dp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    shape = CircleShape
                                )
                                .clickable { colorIndex = index }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(name, palette[colorIndex]) },
                enabled = name.isNotBlank()
            ) { Text("追加") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("やめる") }
        }
    )
}
