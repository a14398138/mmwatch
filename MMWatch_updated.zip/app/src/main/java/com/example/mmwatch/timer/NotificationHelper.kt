package com.example.mmwatch.timer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import com.example.mmwatch.MainActivity
import com.example.mmwatch.R

object NotificationHelper {

    // チャンネルの重要度は作成時に一度決まると端末側に固定される。
    // LOW→DEFAULT に上げても既存インストールには反映されないため、IDを変えて作り直す。
    const val CHANNEL_ID = "mmwatch_running_v2"
    const val NOTIFICATION_ID = 1001

    fun createChannel(context: Context) {
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.channel_name),
            // LOW だと通知シェード内で他アプリの通知より下に埋もれやすい。
            // DEFAULT にして常時表示中でも順位負けしないようにする（音・バイブは引き続きオフ）。
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.channel_desc)
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
        }
        context.getSystemService<NotificationManager>()?.createNotificationChannel(channel)
    }

    fun build(context: Context, state: StopwatchEngine.State): Notification {
        val elapsed = state.elapsedMs()
        val minutes = (elapsed / 60_000L).toInt()
        val icon = TimerIcon.buildIcon(minutes, IconStyleStore.style.value)

        val openApp = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(icon)
            .setContentTitle(state.categoryName.ifBlank { "計測中" })
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp)

        if (state.isRunning) {
            // 秒の表示はシステムのクロノメーターに任せる。通知を毎秒作り直さなくて済む。
            builder.setUsesChronometer(true)
            builder.setWhen(System.currentTimeMillis() - elapsed)
            builder.setShowWhen(true)
            builder.addAction(
                R.drawable.ic_pause, "一時停止",
                servicePendingIntent(context, StopwatchService.ACTION_PAUSE, 11)
            )
        } else {
            builder.setUsesChronometer(false)
            builder.setContentText("一時停止中 ・ ${formatHms(elapsed)}")
            builder.addAction(
                R.drawable.ic_play, "再開",
                servicePendingIntent(context, StopwatchService.ACTION_RESUME, 12)
            )
        }

        builder.addAction(
            R.drawable.ic_stop, "保存して終了",
            servicePendingIntent(context, StopwatchService.ACTION_FINISH, 13)
        )

        return builder.build()
    }

    private fun servicePendingIntent(context: Context, action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, StopwatchService::class.java).setAction(action)
        return PendingIntent.getService(
            context, requestCode, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}

fun formatHms(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(java.util.Locale.US, "%02d:%02d", m, s)
}
