package com.example.mmwatch.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

// Nothing 風。黒と白を基調にして、動作中だけ灯る赤を一点だけ置く。
private val Red = Color(0xFFE7222E)
private val RedDeep = Color(0xFFC4141F)
private val Ink = Color(0xFF000000)
private val InkSoft = Color(0xFF161616)
private val Paper = Color(0xFFFAFAFA)
private val Slate = Color(0xFF3D3D3D)
private val SlateMuted = Color(0xFF8F8F8F)

private val LightColors = lightColorScheme(
    primary = RedDeep,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFBD8D8),
    onPrimaryContainer = Color(0xFF450A0A),
    secondary = Slate,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE3E3E3),
    onSecondaryContainer = Ink,
    background = Paper,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Color(0xFFEAEAEA),
    onSurfaceVariant = Slate,
    outline = SlateMuted,
    error = Color(0xFFB3261E)
)

private val DarkColors = darkColorScheme(
    primary = Red,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF4A0F12),
    onPrimaryContainer = Color(0xFFFAD1D3),
    secondary = Color(0xFFC7C7C7),
    onSecondary = Ink,
    secondaryContainer = Color(0xFF2A2A2A),
    onSecondaryContainer = Color(0xFFE3E3E3),
    background = Ink,
    onBackground = Color(0xFFF2F2F2),
    surface = InkSoft,
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF242424),
    onSurfaceVariant = Color(0xFFB8B8B8),
    outline = Color(0xFF6E6E6E),
    error = Color(0xFFF2B8B5)
)

// 経過時間は等幅で。桁が動いてもレイアウトが揺れない読み取り面にする。
private val AppTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 56.sp,
        letterSpacing = (-1).sp
    ),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        letterSpacing = 0.8.sp
    )
)

@Composable
fun MMWatchTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    MaterialTheme(colorScheme = colors, typography = AppTypography, content = content)
}
